package homework7;

public class Animal {
	void speak(){
		
	}
}
